# A01 Broken Access Control

### 🔖 Metadata

- **OWASP Category (2021): A01 Broken Access Control**
- **PortSwigger Link:** [Access control vulnerabilities and privilege escalation | Web Security Academy](https://portswigger.net/web-security/access-control)

---

### 🧩 Concept

- **What is it?**

> Privilege Escalation via parameter-based access control methods, platform misconfiguration, or URL-matching discrepancies - or circumventing referrer headers, or geolocation mechanisms
> 

> - Vertical = Access to functionality not permitted
 - Horizonal = Access to resources belonging to another user of that type.
> 
- **Impact**

> **- Confidentiality:** Unauthorized users can gain access to sensitive data/restricted areas.
- **Integrity:** Attackers can alter/delete data outside their permissions.
- **Availability:** Critical resources may be exposed, misused, and disabled.
> 

---

### ⚙️ Exploitation Notes

- **Where to test:**

> **- Parameters**: IDs in GET/POST requests (`/user?id=123 → try id=124`).
> 
> 
> **- Headers**: `X-User-Role: admin`
> 
> **- Cookies**: Session IDs, JWT claims (`"role":"admin"`).
> 
> **- Body**: Hidden form fields (`isAdmin=true`)
> 
> **- Endpoints**: Admin panels, debug endpoints, file download/upload routes.
> 
- **Payloads / Tricks used**

> - Modify object IDs → access other users’ records (`/invoice/1001 → /invoice/1002`).
- Replace JWT role claims (`"user" → "admin"`) or use unsigned tokens.
- Force-browse restricted URLs (`/admin`, `/config`, `/logs`).
- Replay/fixate session IDs.
- Abuse CORS misconfigurations to read protected endpoints
> 

---

### 🔍 Detection

- **How to identify in apps**:

> - Try accessing restricted functions as a low-privilege user.
> 
> 
> - Look for **role-based checks missing** on sensitive endpoints.
> 
> - Test API calls directly (curl/Postman) bypassing the UI.
> 
> - Check if session tokens remain valid after logout.
> 
> - Attempt direct object reference (IDOR) with sequential or predictable IDs.
> 
- Burp Suite (Intruder for IDOR testing, Repeater for forced browsing).
- OWASP ZAP with authorization add-ons.

---

### 🛡️ Mitigation

- Zero-Trust, always verify
- Single application-wide mechanism for enforcing access controls.
- At the code level, declare the access that is allowed for each resource, and deny access by default.
- Audit/Test access controls to ensure they work as designed.

---

### 📑 Extras

- **Cheat sheet / references:** [https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html](https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html)

---

- **Labs**
    1. **Unprotected admin functionality**
    1) Append `/robots.txt` to the end of the URL and notice that the ‘`Disallow`’ line discloses the path to the admin panel
    2) Replace `/robots.txt` with `/administrator-panel` to load the page
    3) Delete `carlos`
    2. **Unprotected admin functionality with unpredictable URL**
    1) Look under the hood of the home page via dev-tools
    2) Notice it contains JS that discloses the URL of the admin panel
    3) Load the panel and delete `carlos`
    3. **User role controlled by request parameter**
    1) Browse to /admin and notice access is prevented
    2) Go to login page, and enable interception on Burp Proxy
    3) Complete+Submit the login page → Forward
    4) Observe the response sets Admin=false → Change to Admin=True
    5) Load the panel and delete `carlos`
    4. **User role can be modified in user profile**
    1) Log in with the supplied credentials, access the account page
    2) Update the email address and notice the response contains the role ID
    3) Send the submission request to Burp Repeater, and add `“roleid”:2` into the JSON in the request body - resend it
    4) Notice that the `roleid` has changed to 2 → Go to `/admin` → delete `carlos`
    5. **User ID controlled by request parameter**
    1) Log in with the supplied credentials, access account page
    2) Note the URL contains the username in the “`id`” parameter
    3) Send the request to Burp Repeater
    4) change “`id`” parameter to `carlos`, retrieve and submit the API key for `carlos`
    6. **User ID controlled by request parameter, with unpredictable user IDs**
    1) Find a blog post by `carlos`, click on `carlos` and observe the URL contains his user ID
    2) Log in using the supplied credentials → access account page, and change the `id` parameter to the saved user ID
    3) Retrieve and submit the API key
    7. **User ID controlled by request parameter with data leakage in redirect**
    1)  Log in with the supplied credentials and access the account
    2) Send to Burp Repeater → Change the “`id`” parameter to `carlos`
    3) Observe that even though the response is redirecting to the home page - the body contains the API key belonging to `carlos` → Submit API key
    8. **User ID controlled by request parameter with password disclosure**
    1) Log in with supplied credentials and access the account page
    2) Change the “`id`” parameter in the URL to `administrator` → View response in Burp and notice it contains the administrator’s password
    3) Log into the admin account and delete `carlos`
    9. **Insecure direct object references**
    1) Select the live chat tab
    2) Send a message and select ‘**View Transcript**,’ review the URL and notice the text files assigned a filename containing an incrementing number
    3) Change the filename to `1.txt` and notice a password within that transcript
    4) Return to lab page, and log in with stolen creds.
    10. **URL-based access control can be circumvented**
    1) Load `/admin` and notice you get blocked…. considering the response is plain, it may originate from a front-end system
    2) Send the request to Repeater → Change the URL in the request line to `/` and add the header `X-Original-URL: /invalid`. When the application returns a “not found” response, it indicates that the back-end system is processing the URL from the `X-Original-URL` header
    3) Change the value of the header to `/admin`, and notice access is now enabled.
    4) Delete `carlos` , add `?username=carlos` to the real query string, and change `X-Original-URL` path to `/admin/delete`
    11. **Method-based access control can be circumvented**
    1) Log in using admin credentials provided
    2) Browse to the panel, promote `carlos`, and send the request to Repeater
    3) Open an incognito browser window and log in with the non-admin credentials
    4) Attempt to re-promote `carlos` with the non-admin user by copying that session cookie into the existing Repeater request - and notice the response is “Unauthorized”
    5) Switching the method from `POST` to `POSTX` - the response changes to “missing parameter”
    6) Convert the request to use a `GET` method via selecting “Change request method” when right clicking the request
    7) Change the username parameter to your username, and resend the request
    12. **Multi-step process with no access control on one step**
    1) Log in with the admin creds, browse to the admin panel and promote `carlos`→ Send the confirmation request to Repeater
    2) Open an incognito browser and log in with the non-admin credentials
    3) Copy the non-admin user’s session cookie into the existing Repeater request, change the username to yours, and replay it
    13. **Referer-based access control**
    1) Log in with the admin creds, browse to the admin panel and promote `carlos`→ send the request to Repeater
    2) Open an incognito browser, log in with the non-admin creds
    3) Browse to `/admin-roles?username=carlos&action=upgrade` and observe that the request is unauthorized due to the absent Referer header
    4) Copy the non-admin user’s session cookie into the existing Repeater request, change the username to yours and replay it